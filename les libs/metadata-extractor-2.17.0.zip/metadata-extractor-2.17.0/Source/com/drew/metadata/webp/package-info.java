/**
 * Contains classes for the extraction and modelling of WebP file metadata.
 *
 * @since 2.8.0
 */
package com.drew.metadata.webp;
