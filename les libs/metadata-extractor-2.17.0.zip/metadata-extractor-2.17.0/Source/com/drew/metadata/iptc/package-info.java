/**
 * Contains classes for the extraction and modelling of IPTC metadata.
 */
package com.drew.metadata.iptc;
