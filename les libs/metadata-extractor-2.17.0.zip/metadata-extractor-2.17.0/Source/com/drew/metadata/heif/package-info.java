/**
 * https://dspace.cc.tut.fi/dpub/bitstream/handle/123456789/24147/heikkila.pdf?sequence=1
 */
package com.drew.metadata.heif;
