/**
 * Contains classes for working with AVI files.
 */
package com.drew.imaging.avi;
