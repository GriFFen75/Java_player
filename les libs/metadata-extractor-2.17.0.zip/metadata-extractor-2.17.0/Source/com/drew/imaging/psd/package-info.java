/**
 * Contains classes for working with PSD (PhotoShop Document) files.
 */
package com.drew.imaging.psd;
