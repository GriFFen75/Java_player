/**
 * Contains classes for working with BMP files.
 *
 * @since 2.7.0
 */
package com.drew.imaging.bmp;
